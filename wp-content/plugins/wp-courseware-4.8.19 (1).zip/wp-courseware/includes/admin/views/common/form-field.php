<script type="text/x-template" id="wpcw-form-field">
    <div class="wpcw-form-field" :class="fieldClasses">
        <slot></slot>
    </div>
</script>