<script type="text/x-template" id="wpcw-form-table">
    <table class="wpcw-form-table">
        <tbody>
            <slot></slot>
        </tbody>
    </table>
</script>