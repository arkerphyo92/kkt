<?php
/**
 * WP Courseware Certificate Functions.
 *
 * @package WPCW
 * @subpackage Functions
 * @since 4.6.8
 */

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;
