<?php
   class Redux_Customizer_Control_select extends Redux_Customizer_Control {
     public $type = "redux-select";
   }